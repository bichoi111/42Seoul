#include <unistd.h>

int		main(void)
{
	rush(5, 3);
	return (0);
}
